# PETUNJUK PENGERJAAN

- Clone repo ini
- Kerjakan soal sesuai dengan praktikum yang kamu lakukan (e.g p1 untuk praktikum 1) langsung isi di filenya
- Jika sudah jangan lupa push hasilnya ke github repo pribadi kamu (push per modulnya saja misal folder P1)
- berikan nama reponya proglan-pX-NRP
- Kasih ke aku linknya via wa h-1 sebelum asistensi (1 kelompok 1 perwakilan memberikan 4 link)
- Di modul tugas asistensi, jelaskan saja programnya dan berikan source code beserta ss outputnya.

### beyBLOOD
